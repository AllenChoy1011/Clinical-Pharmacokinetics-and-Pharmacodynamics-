renderInputs <- function(case) {
  wellPanel(
    fluidRow(
      column(6,
             sliderInput(paste0('Nsub_b', case), label = p('Number of subjects', style = 'font-size:12px'),
                         min = 1, max = 100, value = 10, ticks = FALSE)),
      column(6,
             numericInput(paste0('dose_b', case), label = p('Dose', em('(\\( \\mu \\)g)'), style = 'font-size:12px'),
                          min = 0, max = 100, value = 1, step = 0.5))),
    fluidRow(
      column(6,
             numericInput(paste0('CL_b', case), label = p('Clearance', em('(L/h)'), style = 'font-size:12px'),
                          min = 0, max = 100, value = 2, step = 0.5)),
      column(6,
             numericInput(paste0('V_b', case), label = p('Volume', em('(L)'), style = 'font-size:12px'),
                          min = 0, max = 1000, value = 1, step = 0.5))),
    hr(),
    fluidRow(
      column(6,
             numericInput(paste0('base_b', case), label = p('\\( BaselineQT \\)', em('(ms)'), style = 'font-size:12px'),
                          min = 0, max = 1000, value = 400)),
      column(6,
             numericInput(paste0('Ombase_b', case), label = p('Omega \\( BaselineQT \\)', em('(% CV)'), style = 'font-size:12px'),
                          min = 0, max = 100, value = 0))),
    fluidRow(
      column(6,
             numericInput(paste0('emax_b', case), label = p('\\( E_{max} \\)', em('(ms)'), style = 'font-size:12px'),
                          min = 0, max = 1000, value = 100)),
      column(6,
             numericInput(paste0('Omemax_b', case), label = p('Omega \\( E_{max} \\)', em('(% CV)'), style = 'font-size:12px'),
                          min = 0, max = 100, value = 0))),
    fluidRow(
      column(6,
             numericInput(paste0('ec50_b', case), label = p('\\( EC_{50} \\)', em('(\\( \\mu \\)g/L)'), style = 'font-size:12px'),
                          min = 0, max = 20, value = 1)),
      column(6,
             numericInput(paste0('Omec50_b', case), label = p('Omega \\( EC_{50} \\)', em('(% CV)'), style = 'font-size:12px'),
                          min = 0, max = 100, value = 0))),
    hr(),
    fluidRow(
      column(6,
             checkboxInput(paste0('delay_b', case), label = 'Use delay compartment', value = FALSE),
             conditionalPanel(condition = paste0('input.delay_b', case ,' == true'),
                              numericInput(paste0('ke0_b', case), label = p('\\( ke_{0} \\)', em('(\\( h^{-1} \\))'), style = 'font-size:12px'),
                                           min = 0, max = 1000, value = 200))),
      column(6,
             actionButton(paste0('rerun_b', case),
                          label = paste('Rerun trial',ifelse(case == '1', 'A', 'B')), icon = icon('sync'))))
  ) # End wellPanel
} # End renderInputs

ws3b_tab <- fluidPage(
  withMathJax(),
  titlePanel('Dose selection for a first-in-man study'),
  fluidRow(
    column(4, h4('Scenario A')),
    column(4),
    column(4, h4('Scenario B'))
  ),
  fluidRow(
    column(4, renderInputs('1'),
           br(),
           h4('Plot options'),
           wellPanel(
             fluidRow(
               column(6,
                      selectizeInput('tsampl_b', label = p('Sampling times', em('(h)'), style = 'font-size:12px'),
                                     choices = paste(c(seq(from = 0.5, to = 5, by = 0.5), 5:24), 'h'), selected = c('0 h','12 h'),  multiple = TRUE,
                                     options = list(maxItems = 5, placeholder = 'Select max 5 time-pts')),
                      helpText('A sample is drawn at 0-h by default'),
                      downloadButton('dwnl_b', 'Save plots')),
               column(6, 
                      radioButtons('log_b', 
                                   label = p('Conc. scale', style = 'font-size:12px'),
                                   choices = c('Linear', 'Logarithmic'),
                                   inline = TRUE), 
                      radioButtons('smooth_b', 
                                   label = p('Output', style = 'font-size:12px'),
                                   choices = c('Individual', 'Smooth'),
                                   inline = TRUE))
             ) # End fluidRow
           ) # End wellPanel
    ),
    column(4,
           plotOutput('ws3b_pk'),
           plotOutput('ws3b_pd_time'),
           plotOutput('ws3b_pd_conc'),
           # p(code('Safe line is for Task 3 only')),
           HTML(paste('<p><span style="color: #1E90FF;"><em>*Safe line is for <strong>Part&nbsp;3</strong> only</em></span></p>')),
           br()),
    column(4, renderInputs('2'),
           br(),
           conditionalPanel(condition = "input.delay_b1 == true || input.delay_b2 == true",
                            h4('Effect compartment'),
                            plotOutput('ws3b_effpk'))
    )
  ) # End fluidRow
) # End fluidPage

