ws3a_tab <- fluidPage(
  withMathJax(),
  titlePanel('Dose selection for a first-in-man study'),
  br(),
  sidebarLayout(
    sidebarPanel(
      h4('Study design'),
      fluidRow(
        column(6,
               numericInput('Dosea', label = p('Dose', em('(mg)'), style = 'font-size:12px'),
                            min = 0, max = 1000, value = 100)),
        column(6,
               sliderInput('Nsuba', label = p('Number of subjects', style = 'font-size:12px'),
                           min = 1, max = 20, value = 10, ticks = FALSE))),
      fluidRow(
        column(6,
               actionButton(inputId = 'reruna',
                            label = 'Rerun trial', icon = icon('sync'))),
        column(6,
               downloadButton('dwnl_a', 'Save plot'))),
      hr(),
      h4('Model parameters'),
      fluidRow(
        column(6,
               numericInput('CLa', label = p('Clearance', em('(L/min)'), style = 'font-size:12px'),
                            min = 0, max = 100, value = 2)),
        column(6,
               numericInput('OmCLa', label = p('Omega CL', em('(% CV)'), style = 'font-size:12px'),
                            min = 0, max = 100, value = 0))),
      fluidRow(
        column(6,
               numericInput('Va', label = p('Volume', em('(L)'), style = 'font-size:12px'),
                            min = 0, max = 1000, value = 50)),
        column(6,
               numericInput('OmVa', label = p('Omega V', em('(% CV)'), style = 'font-size:12px'),
                            min = 0, max = 100, value = 0))),
      fluidRow(
        column(6,
               numericInput('Siga', label = p('Sigma' , em('(% CV)'), style = 'font-size:12px'),
                            min = 0, max = 100, value = 0))),
      hr(),
      h4('Simulated \\( C_{max} \\) summary'),
      fluidRow(
        column(8, offset = 2, tableOutput('ws3a_summary'))
      ),
      em('\\( C_{max} \\) reported in \\( \\mu \\)g/mL', style = 'font-size:10px')
    ), # sidebarPanel
    mainPanel(
      tabsetPanel(
        tabPanel(title = 'Plot',
                 icon = icon('chart-area'),
                 h4('Graph of individual simulated PK profiles'),
                 plotOutput('ws3a_plot'),
                 radioButtons('loga', 
                              label = h4('Scale'),
                              choices = c('Linear', 'Logarithmic'),
                              inline = TRUE)),
        tabPanel(title = 'Table',
                 icon = icon('table'),
                 h4('Table of individual simulated PK profiles'),
                 DT::dataTableOutput('ws3a_table')),
        tabPanel(title = 'Parameters',
                 icon = icon('th-list'),
                 h4('Table of individual simulated parameters'),
                 column(8, offset = 2,
                        DT::dataTableOutput('ws3a_prms')))
      ) # End tabsetPanel
    ) # End mainPanel
  ) # End sidebarLayout
) # End fluidPage
