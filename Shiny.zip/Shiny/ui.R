library(shiny)
library(shinythemes)

# update on v0.2, commented out instructions


invisible(
  sapply(list.files(path = 'ui_tabs/', full.names = TRUE),
         FUN = sys.source, env = environment())
)

shinyUI(
  navbarPage(title       = 'Clinical PK/PD',
             windowTitle = 'Clinical PK/PD - CTS',
             position    = 'static-top',
             collapsible = TRUE,
             theme       = shinytheme('yeti'),
             footer      = div(hr(style = 'color:grey;width:50%'),
                               p('Property of Uppsala University, 2022', 
                             style = 'color:grey;font-size:11px;text-align:center')),
             # shinythemes::themeSelector(),
             #navbarMenu(title = em('WS3a'),
                        #icon  = icon('area-chart'),
                        # tabPanel(title = em('Instructions'),
                        #          icon  = icon('book'),
                        #          fluidPage(
                        #            column(width = 10, offset = 1,
                        #                   withMathJax(includeMarkdown('markdown/instructions_ws3a.Rmd'))
                        #            ))), # End tabPanel
                        tabPanel(title = em('CTS-PK : Hands-on'),
                                 icon  = icon('chart-area'),
                                 ws3a_tab), # End tabPanel
            # ), # End tabPanel
             #navbarMenu(title = em('WS3b'),
                        #icon  = icon('heartbeat'),
                        # tabPanel(title = em('Instructions'),
                        #          icon  = icon('book'),
                        #          fluidPage(
                        #            column(width = 10, offset = 1,
                        #                   withMathJax(includeMarkdown('markdown/instructions_ws3b.Rmd'))
                        #            ))), # End tabPanel
                        tabPanel(title = em('CTS-QT : Hands-on'),
                                 icon  = icon('heartbeat'),
                                 ws3b_tab), # End tabPanel
            # ), # End navbarMenu
             # tabPanel(title = em('Final report'),
             #          icon  = icon('book'),
             #          fluidPage(
             #            column(width = 10, offset = 1,
             #                   withMathJax(includeMarkdown('markdown/instructions_report.Rmd'))
             #            ))),
             tabPanel(title = 'About',
                      icon = icon('info-circle'),
                      about_tab) # End tabPanel
  ) # End navbarPage
) # End shinyUI
