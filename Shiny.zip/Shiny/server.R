# Load required libraries
library(shiny)
library(tidyr)
library(ggplot2)
library(DT)
library(gridExtra)
library(grid)

options(warn=-1)

# Set see for simulations
set.seed(221287)

# Define time scale for WS3 a and b
time_a  <- seq(from = 0, to = 240, by = 10)
time_b  <- c(0,0.000001,seq(from = 0.1, to = 1, by = 0.1), 2:24)

# Define conc. and effect models
pred_a <- function(dose, time, cl, v, sigma) {
  ipred <- (dose/v)*exp(-(cl/v)*time)
  y     <- ipred * (1 + rnorm(n = length(time), sd = sigma))
  return(y)
}
pred_b <- function(dose, time, cl, v, sigma) {
  tdose <- ifelse(time>=0.000001,dose, 0)
  ipred <- (tdose/v)*exp(-(cl/v)*time)
  y     <- ipred * (1 + rnorm(n = length(time), sd = sigma))
  return(y)
}

pred_ceff <- function(dose, time, cl, v, ke0, delay) {
  tdose <- ifelse(time>=0.000001,dose, 0)
  if (!delay) {
    conc <- (tdose/v)*exp(-(cl/v)*time)
  } else {
    ke0  <- ke0 + 0.000001 # Avoids dividing by 0
    conc <- (tdose*ke0/v) * (exp(-ke0*time)/((cl/v) - ke0) + exp(-(cl/v)*time)/(ke0 - (cl/v)))
  }
  return(conc)
}

pred_eff <- function(dose, time, cl, v, base, emax, ec50, ke0, delay) {
  tdose <- ifelse(time>=0.000001,dose, 0)
  if (!delay) {
    conc <- (tdose/v)*exp(-(cl/v)*time)
  } else {
    ke0  <- ke0 + 0.000001 # Avoids dividing by 0
    conc <- (tdose*ke0/v) * (exp(-ke0*time)/((cl/v) - ke0) + exp(-(cl/v)*time)/(ke0 - (cl/v)))
  }
  y <- base + (emax * conc) / (ec50 + conc)
  return(y)
}

# Define plot functions
plot_w3a <- function(dat, input, title = NULL) {
  ggplot(data = dat$long, aes(x = time, y = conc, group = id)) +
    geom_line(color = 'grey20') +
    labs(title = title,
         x = expression(bold('Time')~('min')),
         y = expression(bold('Drug concentration')~(mu*g/mL))) +
    annotate(geom = 'rect', xmin = -Inf, xmax = Inf, 
             ymin = 10, ymax = Inf, fill = 'coral', alpha = 0.1) +
    annotate(geom = 'text',
             x = mean(c(time_a[1], tail(time_a, 1))),
             y = 10, label = expression("Toxic (">="10 ug/mL)"),
             color = 'coral4', size = 5, vjust = -0.5) +
    theme_gray(base_size = 16) + 
    `if`(input$loga == 'Logarithmic', list(scale_y_log10(breaks = c(0.0001, 0.001, 0.01, 0.1, 1, 10, 100, 1000)),
                                           coord_cartesian(ylim = c(0.0001, 100)),
                                           annotation_logticks(base = 10, sides = 'l', color = 'grey60')), scale_y_continuous())
}

plot_w3b_pk <- function(dat, input, title = NULL) {
  samples <- c(0,as.numeric(gsub('[h]', '', input$tsampl_b)))
  ggplot(data = dat, aes(x = time, y = conc, color = id)) +
    geom_vline(xintercept = samples, 
               color = 'grey50', linetype = '51') +
    geom_hline(yintercept = 0.04,
               color='red',alpha=0.25,linetype='51')+
    geom_line(size = 1) +
    geom_point(data = dat[dat$time %in% samples, ], size = 2) +
    scale_x_continuous(breaks = seq(0, 24, by = 6)) +
    theme_gray(base_size = 16) + 
    theme(legend.position = 'top',
          title = element_text(size = 13),
          plot.margin = unit(c(0,0,0.1,0), 'cm')) +
    labs(title = title,
         color = NULL,
         x = expression(bold('Time')~'(h)'),
         y = expression(bold('Drug concentration')~(mu*g/L))) +
    `if`(input$log_b == 'Logarithmic', list(scale_y_log10(breaks = c(0.0001, 0.001,0.01, 0.1, 1, 10)),
                                            coord_cartesian(ylim = c(0.0001, 10)),
                                            annotation_logticks(base = 10, sides = 'l', color = 'grey60')),
         scale_y_continuous())
}


plot_w3b_effpk <-function(dat, input, title = NULL) {
  samples <- c(0,as.numeric(gsub('[h]', '', input$tsampl_b)))
  ggplot(data = dat, aes(x = time, y = conc, group = interaction(id, group), color = group)) +
    geom_vline(xintercept = samples, 
               color = 'grey50', linetype = '51') +
    geom_line(size = 1) +
    geom_point(data = dat[dat$time %in% samples, ], size = 2) +
    scale_x_continuous(breaks = seq(0, 24, by = 6)) +
    theme_gray(base_size = 16) + 
    theme(legend.position = 'none',#legend.position = 'top',
          title = element_text(size = 13),
          plot.margin = unit(c(0,0,0.1,0), 'cm')) +
    labs(title = title,
         color = NULL,
         x = expression(bold('Time')~'(h)'),
         y = expression(bold('Effect comp. concentration')~(mu*g/L))) +
    `if`(input$log_b == 'Logarithmic', list(scale_y_log10(breaks = c(0.0001, 0.001,0.01, 0.1, 1, 10)),
                                            coord_cartesian(ylim = c(0.0001, 10)),
                                            annotation_logticks(base = 10, sides = 'l', color = 'grey60')),
         scale_y_continuous())
} 

plot_w3b_pd_time <- function(dat, input, title = NULL) {
  samples <- c(0, as.numeric(gsub('[h]', '', input$tsampl_b)))
  ggplot(data = dat, aes(x = time, y = eff, group = interaction(id, group), color = group)) +
    geom_vline(xintercept = samples, 
               color = 'grey50', linetype = '51') +
    annotate(geom = 'rect', xmin = -Inf, xmax = Inf, 
             ymin = 520, ymax = Inf, fill = 'coral', alpha = 0.1) +
    annotate(geom = 'rect', xmin = -Inf, xmax = Inf, 
             ymin = -Inf, ymax = 460, fill = 'dodgerblue3', alpha = 0.1) +
    annotate(geom = 'text',
             x = mean(range(time_b)),
             y = 520, label = expression("Risk of TdP (">= "520 ms)"),
             color = 'coral4', alpha = 0.5, size = 5, vjust = -0.5) +
    annotate(geom = 'text',
             x = mean(range(time_b)),
             y = 460, label = 'Safe (<460 ms)',
             color = 'dodgerblue4', alpha = 0.5, size = 5, vjust = 1.5) +
    `if`(input$smooth_b == 'Individual', 
         list(geom_line(alpha = 0.3),
              geom_point(data = dat[dat$time %in% samples, ], size = 2)),
         geom_smooth(method = 'loess', aes(group = group, fill = group), se = TRUE)) +
    scale_x_continuous(breaks = seq(0, 24, by = 6)) +
    theme_gray(base_size = 16) + 
    theme(legend.position = 'none',
          title = element_text(size = 13),
          plot.margin = unit(c(0,0,0.1,0), 'cm')) +
    labs(title = title,
         color = NULL,
         x = expression(bold('Time')~'(h)'),
         y = expression(bold('QT')~'(ms)'))
}

plot_w3b_pd_conc <- function(dat, input, title = NULL) {
  ggplot(data = dat, aes(x = conc, y = eff, group = interaction(id, group), color = group)) +
    annotate(geom = 'rect', xmin = ifelse(input$log_b == 'Logarithmic', 0, -Inf), xmax = Inf, 
             ymin = 520, ymax = Inf, fill = 'coral', alpha = 0.1) +
    annotate(geom = 'rect', xmin = -Inf, xmax = Inf, 
             ymin = -Inf, ymax = 460, fill = 'dodgerblue3', alpha = 0.1) +
    `if`(input$smooth_b == 'Individual', 
         geom_line(alpha = 0.3),
         geom_smooth(method = 'gam', aes(group = group, fill = group), se = TRUE)) +
    theme_gray(base_size = 16) + 
    theme(legend.position = 'none',
          title = element_text(size = 13),
          plot.margin = unit(c(0,0,0.1,0), 'cm')) +
    guides(fill = guide_legend(override.aes = list(alpha = 0))) +
    labs(title = title,
         color = NULL,
         fill = NULL,
         x = expression(bold('Effect comp. concentration')~(mu*g/L)),
         y = expression(bold('QT')~'(ms)')) + 
    `if`(input$log_b == 'Logarithmic', 
         list(scale_x_log10(breaks = c(0.01, 0.1, 1, 10)),
              coord_cartesian(xlim = c(0.01, 10)),
              annotation_logticks(base = 10, sides = 'b', color = 'grey60')), scale_x_continuous())
}

# Shiny server starts here
shinyServer(function(input, output, session) {
  # ws3a ----------------------------------------------------------------
  # Generate individual parameters vectors
  prms_a <- reactive({
    input$reruna # Create a dependency to the action button
    data.frame(cl = input$CLa * exp(rnorm(n = input$Nsuba, sd = input$OmCLa/100)),
               v  = input$Va * exp(rnorm(n = input$Nsuba, sd = input$OmVa/100)))
  })
  
  # Predict conc. for each parameter vector
  conc_a <- reactive({
    tmp  <- mapply(FUN       = pred_a, 
                   cl        = prms_a()$cl,
                   v         = prms_a()$v,
                   MoreArgs  = list(dose  = input$Dosea,
                                    sigma = input$Siga/100,
                                    time  = time_a))
    tmp  <- as.data.frame(tmp)
    colnames(tmp) <- paste0('id_', 1:input$Nsuba)
    tmp  <- cbind(time = time_a, tmp)
    tmp2 <- gather(tmp, key = id, value = conc, -time)
    return(list(wide = tmp , long = tmp2))
  })
  
  # Output conc. time plot
  output$ws3a_plot <- renderPlot(plot_w3a(conc_a(), input))
  
  # Output conc. time table
  output$ws3a_table <- DT::renderDataTable({
    dat <- conc_a()$wide
    dat[,2:ncol(dat)] <- apply(dat[,2:ncol(dat)], 2, signif, digits = 4)
    colnames(dat) <- c('Time (min)', paste('Conc. ID', 1:input$Nsuba))
    DT::datatable(data = dat,
                  rownames = FALSE,
                  extensions = 'Scroller',
                  filter  = 'none',
                  options = list(deferRender = TRUE,
                                 scrollY = 300,
                                 scrollX = TRUE,
                                 scroller = TRUE,
                                 dom = 'ti'))
  })
  
  # Output parameter vector table
  output$ws3a_prms <- DT::renderDataTable({
    dat <- cbind(paste(1:input$Nsuba), prms_a())
    dat[, 1] <- as.numeric(dat[, 1])
    dat[,2:ncol(dat)] <- apply(dat[,2:ncol(dat)], 2, signif, digits = 4)
    dat <- dat[order(dat[, 1]), ]
    colnames(dat) <- c('ID', 'CL', 'V')
    DT::datatable(data = dat,
                  rownames = FALSE,
                  extensions = 'Scroller',
                  filter  = 'none',
                  options = list(deferRender = TRUE,
                                 scrollY = 330,
                                 scrollX = TRUE,
                                 scroller = TRUE,
                                 dom = 'ti'))
  })
  
  # Output Cmax summary
  output$ws3a_summary <- renderTable({
    cmax <- as.numeric(conc_a()$wide[1, -1])
    data.frame(Mean = mean(cmax),
               Min = min(cmax),
               Max = max(cmax))
  })
  
  # Define save plot function
  output$dwnl_a <- downloadHandler(
    filename = function() { paste0('plot_w3a_', format(Sys.time(), "%d%b%Y_%Hh%M"), '.jpg') },
    content = function(file) {
      jpeg(file, height = 5.5, width = 10, units = 'in', res = 100)
      print(plot_w3a(conc_a(), input, 
                     title = paste0('Trial of ', input$Nsuba, ' subjects dosed at ', 
                                    input$Dosea, ' mg\nCL: ',
                                    input$CLa, ' L/min (', input$OmCLa, '% CV), V: ',
                                    input$Va, ' L (', input$OmVa, '% CV) and Sigma: ', 
                                    input$Siga, '% CV')))
      dev.off()
    })
  
  # ws3b --------------------------------------------------------------------
  # Typical conc. for each scenario
  conc_b <- reactive({
    tmp <- data.frame(time = time_b)
    tmp$SA <- pred_b(dose = input$dose_b1, time = tmp$time, 
                   cl = input$CL_b1, v = input$V_b1, sigma = 0)
    tmp$SB <- pred_b(dose = input$dose_b2, time = tmp$time, 
                   cl = input$CL_b2, v = input$V_b2, sigma = 0)
    tmp <- gather(tmp, key = id, value = conc, -time)
    tmp$id <- factor(tmp$id, levels = c('SA', 'SB'), 
                     labels = paste('Scenario', c('A', 'B')))
    return(tmp)
  })
  
  # Generate individual parameters vectors (scenario A)
  prms_b1 <- reactive({
    input$rerun_b1 # Create a dependency to the action button
    data.frame(base = input$base_b1 * exp(rnorm(n = input$Nsub_b1, sd = input$Ombase_b1/100)),
               emax = input$emax_b1 * exp(rnorm(n = input$Nsub_b1, sd = input$Omemax_b1/100)),
               ec50 = input$ec50_b1 * exp(rnorm(n = input$Nsub_b1, sd = input$Omec50_b1/100)))
  })
  
  # Generate individual parameters vectors (scenario B)
  prms_b2 <- reactive({
    input$rerun_b2 # Create a dependency to the action button
    data.frame(base = input$base_b2 * exp(rnorm(n = input$Nsub_b2, sd = input$Ombase_b2/100)),
               emax = input$emax_b2 * exp(rnorm(n = input$Nsub_b2, sd = input$Omemax_b2/100)),
               ec50 = input$ec50_b2 * exp(rnorm(n = input$Nsub_b2, sd = input$Omec50_b2/100)))
  })
  
  # Predict QT effect for each parameter vector (scenario A)
  eff_b1 <- reactive({
    tmp  <- mapply(FUN       = pred_eff,
                   base      = prms_b1()$base,
                   emax      = prms_b1()$emax,
                   ec50      = prms_b1()$ec50,
                   MoreArgs  = list(dose  = input$dose_b1,
                                    time  = time_b,
                                    cl    = input$CL_b1,
                                    v     = input$V_b1,
                                    ke0   = input$ke0_b1,
                                    delay = input$delay_b1))
    tmp  <- as.data.frame(tmp)
    colnames(tmp) <- paste0('id_', 1:input$Nsub_b1)
    conc <- pred_ceff(dose = input$dose_b1, time = time_b, cl = input$CL_b1, 
                      v = input$V_b1, ke0 = input$ke0_b1, delay = input$delay_b1)
    tmp  <- cbind(time = time_b, conc = conc, tmp)
    tmp <- gather(tmp, key = id, value = eff, -time, -conc)
    tmp$group <- 'Scenario A'
    return(tmp)
  })
  
  
  
  # Predict QT effect for each parameter vector (scenario B)
  eff_b2 <- reactive({
    tmp  <- mapply(FUN       = pred_eff,
                   base      = prms_b2()$base,
                   emax      = prms_b2()$emax,
                   ec50      = prms_b2()$ec50,
                   MoreArgs  = list(dose  = input$dose_b2,
                                    time  = time_b,
                                    cl    = input$CL_b2,
                                    v     = input$V_b2,
                                    ke0   = input$ke0_b2,
                                    delay = input$delay_b2))
    tmp  <- as.data.frame(tmp)
    colnames(tmp) <- paste0('id_', 1:input$Nsub_b2)
    conc <- pred_ceff(dose = input$dose_b2, time = time_b, cl = input$CL_b2, 
                      v = input$V_b2, ke0 = input$ke0_b2, delay = input$delay_b2)
    tmp  <- cbind(time = time_b, conc = conc, tmp)
    tmp  <- gather(tmp, key = id, value = eff, -time, -conc)
    tmp$group <- 'Scenario B'
    return(tmp)
  })
  
  # Output plots
  output$ws3b_pk      <- renderPlot(plot_w3b_pk(conc_b(), input))
  output$ws3b_effpk   <- renderPlot(plot_w3b_effpk(dat = rbind(eff_b1(), eff_b2()), input))
  output$ws3b_pd_time <- renderPlot(plot_w3b_pd_time(dat = rbind(eff_b1(), eff_b2()), input))
  output$ws3b_pd_conc <- renderPlot(plot_w3b_pd_conc(dat = rbind(eff_b1(), eff_b2()), input))
  
  # Define save plot function
  output$dwnl_b <- downloadHandler(
    filename = function() { paste0('plot_w3b_', format(Sys.time(), "%d%b%Y_%Hh%M"), '.jpg') },
    content = function(file) {
      P1 <- plot_w3b_pk(conc_b(), input) +
        theme(plot.margin = unit(c(0.4, 0, 0.4, 0.4), 'cm'),
              legend.position = 'none') 
      
      P2 <- plot_w3b_pd_time(rbind(eff_b1(), eff_b2()), input) +
        theme(plot.margin = unit(c(0.4, 0, 0.4, 0.4), 'cm'))
      
      P3 <- plot_w3b_pd_conc(rbind(eff_b1(), eff_b2()), input) +
        theme(plot.margin = unit(c(0.4, 0, 0.4, 0.4), 'cm'),
              legend.position = 'right')
      
      jpeg(file, height = 5.5, width = 15, units = 'in', res = 100)
      gridExtra::grid.arrange(P1, P2, P3, ncol = 3, widths = c(0.3, 0.3, 0.4),
                              top = grid::textGrob(label = paste0('Scenario A (PK: ', input$dose_b1, ' ug dose, CL=', input$CL_b1, ' L/h, V=', input$V_b1, ' L | PD: ',
                                                                  input$Nsub_b1, ' ID, BaseQT=', input$base_b1, ' ms (', input$Ombase_b1 ,'%CV), Emax=',
                                                                  input$emax_b1, ' ms (',input$Omemax_b1, '%CV), EC50=', input$ec50_b1, ' ug/L (', input$Omec50_b1, '%CV)',
                                                                  ifelse(input$delay_b1, paste0(' Ke0=', input$ke0_b1, ' h-1'), ''),
                                                                  '\nScenario B (PK: ', input$dose_b2, ' ug dose, CL=', input$CL_b2, ' L/h, V=', input$V_b2, ' L | PD: ',
                                                                  input$Nsub_b2, ' ID, BaseQT=', input$base_b2, ' ms (', input$Ombase_b2 ,'%CV), Emax=',
                                                                  input$emax_b2, ' ms (',input$Omemax_b2, '%CV), EC50=', input$ec50_b2, ' ug/L (',input$Omec50_b2 ,'%CV)',
                                                                  ifelse(input$delay_b2, paste0(' Ke0=', input$ke0_b2, ' h-1'), '') )))
      dev.off()
    })
  
  session$onSessionEnded(function() {              # stop-app code
    stopApp()
  })
  
  
}) # End shinyServer
